from tourismex import app
