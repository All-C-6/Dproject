let sendButton = document.getElementById('send_message');
let chatblock = document.getElementById('chatblock');
let messageText = document.getElementById('message_text');
const hide = document.getElementById('ISU_logo');
const ms6 = document.getElementById('message_6');
const ms7 = document.getElementById('message_7');
const header = document.getElementById('header');



sendButton.addEventListener('click',function(){
    setTimeout(function(){

      let div = document.createElement('div');
      div.setAttribute('class', 'flex flex-row items-end p-2 my-2 mr-2');
      let p = document.createElement('p');
      p.setAttribute('class', 'bg-color_base rounded p-2 w-full');
      p.innerHTML = messageText.value;
      let img = document.createElement('img');
      img.setAttribute('src', "/static/pic/usericon_default.png")
      img.setAttribute('alt', 'Дефолтное изображение');
      img.setAttribute('height','50px');
      img.setAttribute('width','50px');
      div.appendChild(p);
      div.appendChild(img);
      chatblock.appendChild(div);
    },100);
    setTimeout(function(){
        let div2 = document.createElement('div');
      div2.setAttribute('class', 'flex flex-row-reverse items-end p-2 my-2 mr-2');
      let p2 = document.createElement('p');
      p2.setAttribute('class', 'bg-color_base rounded p-2 w-full');
      p2.innerHTML = "Это сообщение с планшета";
      let img2 = document.createElement('img');
      img2.setAttribute('src', "/static/pic/usericon_default.png")
      img2.setAttribute('alt', 'Дефолтное изображение');
      img2.setAttribute('height','50px');
      img2.setAttribute('width','50px');
      div2.appendChild(p2);
      div2.appendChild(img2);
      chatblock.appendChild(div2);
    },4500);
});

document.addEventListener('DOMContentLoaded', () => {
    ms6.classList.add('hidden');
    ms7.classList.add('hidden');
});

header.addEventListener('click', () => {
    if (event.target == header) {
        ms6.classList.remove('hidden');
        ms7.classList.remove('hidden');
       }
});